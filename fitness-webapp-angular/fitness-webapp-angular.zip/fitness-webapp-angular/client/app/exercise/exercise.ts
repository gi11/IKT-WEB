export class Exercise {
  _id: string;
  name: string;
  description: string;
  set: number;
  repeat_count: number;
  repeat_type: string;
}
