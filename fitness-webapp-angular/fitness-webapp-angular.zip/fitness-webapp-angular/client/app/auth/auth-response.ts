export class AuthResponse {
  url: string;
  user: object;
  token: string;
}
