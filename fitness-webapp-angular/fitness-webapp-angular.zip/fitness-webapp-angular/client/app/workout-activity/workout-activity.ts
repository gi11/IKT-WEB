export class WorkoutActivity {
  _userId: string;
  username: string;
  exerciseName: string;
  _workoutId: string;
  _exerciseId: string;
}
